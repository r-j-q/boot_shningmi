<template>
	<!-- 缺省页 -->
	<shopro-empty :image="$IMG_URL + '/imgs/empty/template_empty.png'" tipText="404,页面走丢了~" btnText="去首页逛逛" @click="$Router.pushTab('/pages/index/index')"></shopro-empty>
</template>

<script></script>

<style></style>
